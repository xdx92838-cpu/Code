/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-25: Notas e aprova��o
Uma escola deseja automatizar a verifica��o das notas dos alunos.
O sistema deve receber a m�dia final do estudante e informar se ele foi aprovado, em recupera��o ou
reprovado.
*/
#include <stdio.h>

int main() {
    float media;

    printf("Digite a media: ");
    scanf("%f", &media);

    if (media >= 7)
        printf("Aprovado");
    else if (media >= 5)
        printf("Recuperacao");
    else
        printf("Reprovado");

    return 0;
}
