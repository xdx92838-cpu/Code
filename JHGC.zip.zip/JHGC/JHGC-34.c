/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-34: Verificar se um n�mero � primo
Um estudante est� aprendendo sobre n�meros primos e quer automatizar a verifica��o.
O programa deve receber um n�mero e informar se ele � primo utilizando for.
*/
#include <stdio.h>

int main() {
    int n, i, primo = 1;

    scanf("%d", &n);

    if(n <= 1)
        primo = 0;

    for(i = 2; i < n; i++) {
        if(n % i == 0) {
            primo = 0;
            break;
        }
    }

    if(primo)
        printf("Primo");
    else
        printf("Nao primo");

    return 0;
}
