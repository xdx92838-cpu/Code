/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-46: Contar de 1 a 10
Uma escola est� ensinando estruturas de repeti��o para iniciantes em programa��o.
O programa deve imprimir os n�meros de 1 at� 10, um por linha, utilizando do...while.
*/
#include <stdio.h>

int main() {
    int i = 1;

    do {
        printf("%d\n", i);
        i++;
    } while(i <= 10);

    return 0;
}
