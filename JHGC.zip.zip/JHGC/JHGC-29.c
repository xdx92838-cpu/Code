/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-29: N�meros pares de 0 a 50
Um jogo educativo precisa mostrar apenas os n�meros pares para ensinar matem�tica b�sica.
O programa deve exibir todos os n�meros pares entre 0 e 50.
*/
#include <stdio.h>

int main() {
    int i;

    for(i = 0; i <= 50; i += 2)
        printf("%d\n", i);

    return 0;
}
