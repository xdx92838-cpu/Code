/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-40: Tabuada com while
Um aluno deseja praticar multiplica��o usando repeti��o.
O programa deve receber um n�mero e mostrar sua tabuada de 1 a 10 utilizando while.
*/
#include <stdio.h>

int main() {
    int n, i = 1;

    scanf("%d", &n);

    while(i <= 10) {
        printf("%d x %d = %d\n", n, i, n * i);
        i++;
    }

    return 0;
}
