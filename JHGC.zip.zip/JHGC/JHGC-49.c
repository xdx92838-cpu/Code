/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-49:  Pedir senha at� acertar
Uma escola criou um sistema simples para liberar o acesso ao laborat�rio de inform�tica.
O programa deve solicitar a senha do usu�rio repetidamente at� que ele digite a senha correta (1111).
Quando acertar, o sistema deve mostrar a mensagem �Acesso liberado!�.
*/
#include <stdio.h>

int main() {
    int senha;

    do {
        scanf("%d", &senha);
    } while(senha != 1111);

    printf("Acesso liberado!");

    return 0;
}
