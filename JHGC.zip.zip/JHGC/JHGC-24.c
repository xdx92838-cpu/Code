/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-24: Pode votar?
Um sistema de cadastro eleitoral precisa verificar se uma pessoa j� possui idade para votar.
O usu�rio informa sua idade, e o programa deve dizer se ele pode ou n�o votar.
*/
#include <stdio.h>

int main() {
    int idade;

    printf("Digite sua idade: ");
    scanf("%d", &idade);

    if (idade >= 16)
        printf("Pode votar");
    else
        printf("Nao pode votar");

    return 0;
}
