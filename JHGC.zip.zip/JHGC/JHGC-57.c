/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-57: A Central do Brinquedo Eletr�nico
Um urso de pel�cia eletr�nico tem um bot�o central. Cada vez que a crian�a aperta o bot�o, o
urso fala uma frase diferente dependendo da cor que acende na sua barriga.
O Exerc�cio: Desenvolva a l�gica do urso. O algoritmo deve receber uma palavra (texto) com a
cor que acendeu e exibir a fala do brinquedo:
"Verde": O urso diz: "Vamos brincar l� fora!"
"Amarelo": O urso diz: "Estou ficando com soninho..."
"Vermelho": O urso diz: "Estou com fome, hora do lanche!"
Caso seja outra cor: O urso apenas pisca as luzes (Mensagem: "Cor desconhecida").
*/
#include <stdio.h>
#include <string.h>

int main() {
    char cor[20];

    scanf("%s", cor);

    if(strcmp(cor, "Verde") == 0)
        printf("Vamos brincar la fora!");
    else if(strcmp(cor, "Amarelo") == 0)
        printf("Estou ficando com soninho...");
    else if(strcmp(cor, "Vermelho") == 0)
        printf("Estou com fome, hora do lanche!");
    else
        printf("Cor desconhecida");

    return 0;
}
