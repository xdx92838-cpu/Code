/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-30: Fatorial de um n�mero
Um aluno de matem�tica precisa calcular o fatorial de alguns n�meros para resolver exerc�cios escolares.
O programa deve receber um n�mero e calcular seu fatorial utilizando for.
*/
#include <stdio.h>

int main() {
    int n, i;
    long long fat = 1;

    scanf("%d", &n);

    for(i = 1; i <= n; i++)
        fat *= i;

    printf("Fatorial = %lld", fat);

    return 0;
}
