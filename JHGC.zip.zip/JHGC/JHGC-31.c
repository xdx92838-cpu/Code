/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-31: Contagem regressiva
Uma competi��o escolar utiliza uma contagem regressiva antes da largada.
O programa deve mostrar os n�meros de 10 at� 1 na tela.
*/
#include <stdio.h>

int main() {
    int i;

    for(i = 10; i >= 1; i--)
        printf("%d\n", i);

    return 0;
}
