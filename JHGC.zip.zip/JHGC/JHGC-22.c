/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-22: Par ou �mpar
Em um jogo educativo, o participante digita um n�mero para descobrir sua classifica��o.
O programa deve verificar se o n�mero informado � par ou �mpar.
*/
#include <stdio.h>

int main() {
    int n;

    printf("Digite um numero: ");
    scanf("%d", &n);

    if (n % 2 == 0)
        printf("Par");
    else
        printf("Impar");

    return 0;
}
