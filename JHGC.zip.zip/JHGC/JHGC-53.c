/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-53: Confirmar sa�da com 's'
Um programa de cadastro possui um menu simples de op��es.
Ap�s cada opera��o, o sistema deve perguntar se o usu�rio deseja sair. O menu continuar� aparecendo at�
que o usu�rio digite a letra �s�.
*/
#include <stdio.h>

int main() {
    char op;

    do {
        printf("Menu executado\n");
        printf("Deseja sair? (s/n): ");
        scanf(" %c", &op);

    } while(op != 's' && op != 'S');

    return 0;
}
