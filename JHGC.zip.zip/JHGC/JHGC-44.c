/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-44: Contar d�gitos de um n�mero
Um sistema banc�rio deseja identificar quantos d�gitos possui um n�mero informado.
O programa deve receber um n�mero positivo e mostrar quantos d�gitos ele possui.
*/
#include <stdio.h>

int main() {
    int n, cont = 0;

    scanf("%d", &n);

    while(n > 0) {
        cont++;
        n /= 10;
    }

    printf("Digitos: %d", cont);

    return 0;
}
