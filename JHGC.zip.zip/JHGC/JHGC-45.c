/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-45: Menu at� escolher sair
Um caixa eletr�nico simples apresenta op��es ao usu�rio.
O programa deve exibir um menu repetidamente at� que a op��o �sair� seja escolhida.
*/
#include <stdio.h>

int main() {
    int op;

    do {
        printf("\n1 - Opcao A");
        printf("\n2 - Opcao B");
        printf("\n0 - Sair\n");

        scanf("%d", &op);

    } while(op != 0);

    return 0;
}
