/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-60: O Validador de Dias �teis
O sistema de catracas de uma empresa precisa saber se um funcion�rio pode entrar no pr�dio.
No s�bado e no domingo a empresa fecha, e a entrada s� � permitida de segunda a sexta-feira.
O Exerc�cio: Crie um script que receba um n�mero de 1 a 7 (onde 1 � Domingo, 2 � Segunda, e
assim por diante). O programa deve agrupar os casos e exibir se � um dia de trabalho ou
descanso:
2, 3, 4, 5, 6: Exibir "Dia �til. Acesso liberado para o trabalho."
1, 7: Exibir "Fim de Semana. Pr�dio fechado."
Outros n�meros: "N�mero de dia inv�lido."
*/
#include <stdio.h>

int main() {
    int dia;

    scanf("%d", &dia);

    switch(dia) {
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            printf("Dia Util. Acesso liberado para o trabalho.");
            break;

        case 1:
        case 7:
            printf("Fim de Semana. Predio fechado.");
            break;

        default:
            printf("Numero de dia invalido.");
    }

    return 0;
}
