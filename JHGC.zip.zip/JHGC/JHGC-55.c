/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-55: Ler n�meros e mostrar o maior (at� digitar negativo)
Uma pesquisa escolar registra notas positivas dos participantes.
O programa deve continuar recebendo n�meros at� que um valor negativo seja digitado. Ao final, deve
mostrar qual foi o maior n�mero positivo informado.
*/
#include <stdio.h>

int main() {
    int n, maior = 0;

    do {
        scanf("%d", &n);

        if(n > maior)
            maior = n;

    } while(n >= 0);

    printf("Maior numero: %d", maior);

    return 0;
}
