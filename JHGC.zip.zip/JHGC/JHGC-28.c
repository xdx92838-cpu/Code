/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-28: Soma dos 100 primeiros n�meros naturais
Uma loja deseja calcular rapidamente a soma de uma sequ�ncia de n�meros para um relat�rio simples.
O programa deve calcular a soma dos n�meros de 1 at� 100 utilizando um la�o for.
*/
#include <stdio.h>

int main() {
    int i, soma = 0;

    for(i = 1; i <= 100; i++)
        soma += i;

    printf("Soma = %d", soma);

    return 0;
}
