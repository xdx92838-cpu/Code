/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-27: Tabuada de um n�mero
Um estudante est� treinando matem�tica e deseja visualizar rapidamente a tabuada de um n�mero.
O programa deve receber um n�mero digitado pelo usu�rio e mostrar sua tabuada de 1 a 10 usando for.
*/
#include <stdio.h>

int main() {
    int n, i;

    scanf("%d", &n);

    for(i = 1; i <= 10; i++)
        printf("%d x %d = %d\n", n, i, n * i);

    return 0;
}
