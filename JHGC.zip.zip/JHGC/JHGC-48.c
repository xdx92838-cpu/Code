/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-48: Menu com op��o de sair
Fa�a um programa mostrando um menu de op��es. Ele fica pedindo para o usu�rio escolher entre duas op��es
(digitar 1 para mostrar uma mensagem ou 2 para sair) at� que o usu�rio escolha a op��o 2. O fluxo de execu��o � o
seguinte:
O programa exibe o menu com as op��es: "1 - Mensagem" ou "2 - Sair".
Se o usu�rio escolher 1, ele imprime a mensagem "Voc� escolheu a mensagem!".
O programa continuar� executando o menu at� que o usu�rio escolha 2 para sair.
*/
#include <stdio.h>

int main() {
    int op;

    do {
        printf("\n1 - Mensagem");
        printf("\n2 - Sair\n");

        scanf("%d", &op);

        if(op == 1)
            printf("Voce escolheu a mensagem!\n");

    } while(op != 2);

    return 0;
}
