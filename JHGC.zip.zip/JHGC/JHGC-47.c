/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-47: Tabuada de um número
Um estudante quer praticar multiplicação usando a estrutura do...while.
O programa deve receber um número e exibir sua tabuada de 1 até 10.
*/
#include <stdio.h>

int main() {
    int n, i = 1;

    scanf("%d", &n);

    do {
        printf("%d x %d = %d\n", n, i, n * i);
        i++;
    } while(i <= 10);

    return 0;
}
