/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-58: A Calculadora de Bolso de 4 Opera��es
Voc� foi desafiado a criar o motor l�gico de uma calculadora de bolso bem simples, daquelas
que s� fazem as quatro opera��es b�sicas.
O Exerc�cio: O algoritmo deve receber dois n�meros reais (ex: 10 e 5) e um caractere
representando a opera��o matem�tica ('+', '-', '*', '/'). Use o Switch...Case para analisar o
caractere da opera��o e exibir o resultado do c�lculo correspondente.
Caso receba um s�mbolo diferente dos quatro: Exiba "Opera��o matem�tica n�o reconhecida".
*/
#include <stdio.h>

int main() {
    float a, b;
    char op;

    scanf("%f %f %c", &a, &b, &op);

    switch(op) {
        case '+':
            printf("%.2f", a + b);
            break;
        case '-':
            printf("%.2f", a - b);
            break;
        case '*':
            printf("%.2f", a * b);
            break;
        case '/':
            printf("%.2f", a / b);
            break;
        default:
            printf("Operacao matematica nao reconhecida");
    }

    return 0;
}
