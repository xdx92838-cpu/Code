/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-37: Soma de n�meros at� digitar zero
Um caixa simples de mercado precisa somar valores digitados pelo operador.
O programa deve continuar recebendo n�meros at� que o usu�rio digite 0 e, ao final, mostrar a soma total.
*/
#include <stdio.h>

int main() {
    int n, soma = 0;

    do {
        scanf("%d", &n);
        soma += n;
    } while(n != 0);

    printf("Soma = %d", soma);

    return 0;
}
