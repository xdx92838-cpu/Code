/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-43: Soma dos pares entre 1 e 100
Um professor prop�s um desafio para calcular apenas os n�meros pares de uma sequ�ncia.
O programa deve somar todos os n�meros pares entre 1 e 100 utilizando while.
*/
#include <stdio.h>

int main() {
    int i = 2, soma = 0;

    while(i <= 100) {
        soma += i;
        i += 2;
    }

    printf("Soma = %d", soma);

    return 0;
}
