/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-23: Maior de dois n�meros
Dois atletas registraram suas pontua��es em uma prova.
O sistema precisa identificar qual foi a maior pontua��o.
O programa deve receber dois n�meros e mostrar qual deles � o maior.
*/
#include <stdio.h>

int main() {
    int a, b;

    scanf("%d %d", &a, &b);

    if (a > b)
        printf("Maior: %d", a);
    else
        printf("Maior: %d", b);

    return 0;
}
