/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-41: N�mero primo com while
Um estudante deseja verificar se determinado n�mero � primo utilizando outro tipo de repeti��o.
O programa deve testar se o n�mero possui apenas dois divisores usando while.
*/
#include <stdio.h>

int main() {
    int n, i = 2, primo = 1;

    scanf("%d", &n);

    if(n <= 1)
        primo = 0;

    while(i < n) {
        if(n % i == 0) {
            primo = 0;
            break;
        }
        i++;
    }

    if(primo)
        printf("Primo");
    else
        printf("Nao primo");

    return 0;
}
