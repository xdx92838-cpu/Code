/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-52: Soma at� o n�mero ser m�ltiplo de 10
Um sistema de pontua��o recebe v�rios valores digitados pelo usu�rio.
Os n�meros devem ser somados continuamente at� que seja digitado um n�mero m�ltiplo de 10. Ao final, o
programa deve mostrar a soma total dos valores informados.
*/
#include <stdio.h>

int main() {
    int n, soma = 0;

    do {
        scanf("%d", &n);
        soma += n;
    } while(n % 10 != 0);

    printf("Soma = %d", soma);

    return 0;
}
