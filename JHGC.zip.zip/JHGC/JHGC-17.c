/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-17: O Sensor do Parque Tem�tico
Voc� foi contratado para programar o sistema de seguran�a de uma nova montanha-russa em um parque de
divers�es. Por motivos de seguran�a, existe uma altura m�nima de 140 cent�metros (1,40m) para poder
entrar no brinquedo.
Na entrada, h� um sensor digital que mede a altura da crian�a em cent�metros. O seu trabalho � criar o
algoritmo que l� essa altura e decide se o painel vai acender a luz verde (liberado) ou a luz vermelha
(barrado).
*/

#include <stdio.h>

int main() {
    int altura;

    printf("Digite a altura em cm: ");
    scanf("%d", &altura);

    if (altura >= 140)
        printf("Liberado");
    else
        printf("Barrado");

    return 0;
}
