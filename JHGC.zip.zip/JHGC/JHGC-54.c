/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-54: Validar n�mero entre 1 e 5
Um jogo educativo aceita apenas n�veis de dificuldade entre 1 e 5.
O programa deve pedir ao usu�rio um n�mero dentro desse intervalo e continuar solicitando enquanto o
valor digitado for inv�lido.
*/
#include <stdio.h>

int main() {
    int n;

    do {
        scanf("%d", &n);
    } while(n < 1 || n > 5);

    printf("Numero valido");

    return 0;
}
