/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-50: N�mero positivo obrigat�rio
Um aplicativo banc�rio aceita apenas valores positivos para dep�sitos.
O programa deve pedir ao usu�rio um n�mero positivo e continuar solicitando enquanto ele digitar valores
menores ou iguais a zero.
*/
#include <stdio.h>

int main() {
    int n;

    do {
        scanf("%d", &n);
    } while(n <= 0);

    printf("Numero valido");

    return 0;
}
