/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-19: Ordem crescente (tr�s n�meros)
Durante uma competi��o escolar, tr�s alunos obtiveram pontua��es diferentes.
O sistema precisa organizar os valores do menor para o maior para facilitar a classifica��o.
O programa deve receber tr�s n�meros e exibi-los em ordem crescente.
*/
#include <stdio.h>

int main() {
    int a, b, c, temp;

    scanf("%d %d %d", &a, &b, &c);

    if (a > b) { temp = a; a = b; b = temp; }
    if (a > c) { temp = a; a = c; c = temp; }
    if (b > c) { temp = b; b = c; c = temp; }

    printf("%d %d %d", a, b, c);

    return 0;
}
