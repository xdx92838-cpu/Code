/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-42: Quantidade de n�meros �mpares digitados
Uma pesquisa escolar precisa analisar n�meros digitados pelos participantes.
O programa deve pedir 10 n�meros e informar quantos deles s�o �mpares.
*/
#include <stdio.h>

int main() {
    int n, i = 1, cont = 0;

    while(i <= 10) {
        scanf("%d", &n);

        if(n % 2 != 0)
            cont++;

        i++;
    }

    printf("Quantidade de impares: %d", cont);

    return 0;
}
