/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-20: Ano bissexto
Uma agenda digital precisa descobrir se determinado ano ter� 366 dias.
O usu�rio informa um ano, e o programa deve verificar se ele � bissexto ou n�o.
*/
#include <stdio.h>

int main() {
    int ano;

    printf("Digite o ano: ");
    scanf("%d", &ano);

    if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0))
        printf("Ano bissexto");
    else
        printf("Ano nao bissexto");

    return 0;
}
