/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-51: Contagem regressiva de 10 at� 1
Uma corrida escolar utiliza uma contagem regressiva antes da largada.
O programa deve mostrar os n�meros de 10 at� 1 em ordem decrescente utilizando do...while.
*/
#include <stdio.h>

int main() {
    int i = 10;

    do {
        printf("%d\n", i);
        i--;
    } while(i >= 1);

    return 0;
}
