/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-35: N�meros de Fibonacci (n termos)
Um clube de matem�tica quer estudar a famosa sequ�ncia de Fibonacci.
O programa deve pedir um valor n e mostrar os primeiros termos da sequ�ncia.
*/
#include <stdio.h>

int main() {
    int n, i;
    int a = 0, b = 1, c;

    scanf("%d", &n);

    for(i = 1; i <= n; i++) {
        printf("%d ", a);
        c = a + b;
        a = b;
        b = c;
    }

    return 0;
}
