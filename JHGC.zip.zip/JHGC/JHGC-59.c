/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-59: O Assistente de Dire��o (GPS Sem Mapa)
Um rob� de entregas aut�nomo est� andando por uma f�brica. Ele l� placas com letras que
indicam para qual dire��o ele deve virar nas esquinas dos corredores.
O Exerc�cio: Fa�a um programa que leia uma letra mai�scula digitada e exiba o comando de voz
do rob�:
'N': "Seguir para o Norte."
'S': "Seguir para o Sul."
'L': "Virar � Leste (Direita)."
'O': "Virar � Oeste (Esquerda)."
Qualquer outra letra: "Comando inv�lido! Pare o rob�."
*/
#include <stdio.h>

int main() {
    char dir;

    scanf(" %c", &dir);

    switch(dir) {
        case 'N':
            printf("Seguir para o Norte.");
            break;
        case 'S':
            printf("Seguir para o Sul.");
            break;
        case 'L':
            printf("Virar a Leste (Direita).");
            break;
        case 'O':
            printf("Virar a Oeste (Esquerda).");
            break;
        default:
            printf("Comando invalido! Pare o robo.");
    }

    return 0;
}
