/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-33: M�ltiplos de 3 entre 1 e 30
Um aplicativo educacional deseja destacar os n�meros m�ltiplos de 3 para os alunos.
O programa deve listar todos os m�ltiplos de 3 entre 1 e 30.
*/
#include <stdio.h>

int main() {
    int i;

    for(i = 3; i <= 30; i += 3)
        printf("%d\n", i);

    return 0;
}
