/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-15: Quantas caixas cabem dentro do caminh�o

Uma empresa de log�stica precisa calcular quantas caixas podem ser transportadas em um caminh�o sem
ultrapassar o espa�o dispon�vel.
O sistema deve receber as dimens�es do caminh�o e das caixas (altura, largura e comprimento) e calcular
quantas caixas cabem no interior do ve�culo.
O programa dever� utilizar vari�veis para armazenar os valores e, como teste, o aluno deve digitar os valores
fornecidos pelo professor para verificar o resultado do c�lculo.
*/

#include <stdio.h>

int main() {
    float ac, lc, cc;
    float ax, lx, cx;

    printf("Altura, largura e comprimento do caminhao: ");
    scanf("%f %f %f", &ac, &lc, &cc);

    printf("Altura, largura e comprimento da caixa: ");
    scanf("%f %f %f", &ax, &lx, &cx);

    int qtd = (ac / ax) * (lc / lx) * (cc / cx);

    printf("Quantidade de caixas: %d", qtd);

    return 0;
}
