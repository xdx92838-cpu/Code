/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-26:  Contar de 1 a 10
Um professor quer que o computador mostre automaticamente os n�meros usados em uma chamada de
alunos.
O programa deve imprimir os n�meros de 1 at� 10 utilizando um la�o for.
*/
#include <stdio.h>

int main() {
    int i;

    for(i = 1; i <= 10; i++)
        printf("%d\n", i);

    return 0;
}
