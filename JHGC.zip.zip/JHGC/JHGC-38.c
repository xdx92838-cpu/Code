/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-38: Senha correta
Um sistema de acesso precisa garantir que apenas usu�rios autorizados entrem.
O programa deve solicitar a senha repetidamente at� que o usu�rio digite a senha correta.
*/
#include <stdio.h>

int main() {
    int senha;

    while(1) {
        scanf("%d", &senha);

        if(senha == 1234)
            break;

        printf("Senha incorreta\n");
    }

    printf("Acesso liberado");

    return 0;
}
