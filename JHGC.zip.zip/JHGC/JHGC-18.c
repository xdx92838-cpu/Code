/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-18: Login simples
Uma escola criou um sistema simples para acesso � biblioteca digital.
O aluno deve informar usu�rio e senha corretos para entrar no sistema.
O programa deve verificar se os dados digitados est�o corretos e mostrar uma mensagem de acesso
permitido ou negado.
*/

#include <stdio.h>
#include <string.h>

int main() {
    char usuario[20];
    char senha[20];

    printf("Usuario: ");
    scanf("%s", usuario);

    printf("Senha: ");
    scanf("%s", senha);

    if (strcmp(usuario, "admin") == 0 && strcmp(senha, "1234") == 0)
        printf("Acesso permitido");
    else
        printf("Acesso negado");

    return 0;
}
