/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-36: Contar at� 10 com while
Uma crian�a est� aprendendo contagem num�rica no computador.
O programa deve imprimir os n�meros de 1 at� 10 usando while.
*/
#include <stdio.h>

int main() {
    int i = 1;

    while(i <= 10) {
        printf("%d\n", i);
        i++;
    }

    return 0;
}
