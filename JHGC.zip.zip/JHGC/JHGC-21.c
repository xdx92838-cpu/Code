/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-21: N�mero positivo ou negativo
Um aplicativo financeiro registra lucros e preju�zos.
Valores positivos representam lucro e valores negativos representam preju�zo.
O programa deve receber um n�mero e informar se ele � positivo, negativo ou zero.
*/
#include <stdio.h>

int main() {
    int n;

    printf("Digite um numero: ");
    scanf("%d", &n);

    if (n > 0)
        printf("Positivo");
    else if (n < 0)
        printf("Negativo");
    else
        printf("Zero");

    return 0;
}
