/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-39: Verificar se um n�mero � positivo
Um sistema financeiro s� aceita valores positivos para cadastro.
O programa deve continuar pedindo n�meros at� que o usu�rio digite um n�mero positivo.
*/
#include <stdio.h>

int main() {
    int n;

    do {
        scanf("%d", &n);
    } while(n <= 0);

    printf("Numero valido");

    return 0;
}
