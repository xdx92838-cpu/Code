/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-16:  M�ltiplo de 3 e/ou 5
Uma lanchonete criou uma promo��o especial.
Se o n�mero do pedido for m�ltiplo de 3, o cliente ganha um refrigerante.
Se for m�ltiplo de 5, ganha uma sobremesa.
Se for m�ltiplo dos dois, ganha os dois brindes.
O programa deve verificar o n�mero do pedido e informar qual pr�mio o cliente ganhou.
*/
#include <stdio.h>

int main() {
    int n;

    printf("Digite um numero: ");
    scanf("%d", &n);

    if (n % 3 == 0 && n % 5 == 0)
        printf("Ganha refrigerante e sobremesa");
    else if (n % 3 == 0)
        printf("Ganha refrigerante");
    else if (n % 5 == 0)
        printf("Ganha sobremesa");
    else
        printf("Nao ganhou premio");

    return 0;
}
