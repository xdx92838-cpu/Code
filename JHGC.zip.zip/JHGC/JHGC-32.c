/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-32: Quadrado dos n�meros de 1 a 10
Um professor quer demonstrar o conceito de pot�ncia ao quadrado para a turma.
O programa deve mostrar o quadrado de cada n�mero de 1 at� 10.
*/
#include <stdio.h>

int main() {
    int i;

    for(i = 1; i <= 10; i++)
        printf("%d² = %d\n", i, i * i);

    return 0;
}
