/*
Nome: Jos� Heitor Gon�alves Costa
RA: 0027053

JHGC-56: O Menu do Fast-Food Digital
Voc� est� programando o totem de autoatendimento de uma lanchonete. O cliente v� uma tela
com as op��es de combos e digita o n�mero do seu pedido.
O Exerc�cio: Crie um algoritmo que leia um n�mero inteiro de 1 a 4 correspondente ao combo
escolhido e mostre o nome do prato e o valor:
1: "Combo Hamb�rguer + Batata + Refri - R$ 30,00"
2: "Combo Pizza Brotinho + Refri - R$ 25,00"
3: "Combo Salada + Suco Natural - R$ 22,00"
4: "Combo Balde de Frango + Molho - R$ 35,00"
Caso digite qualquer outro n�mero (Default): "Op��o inv�lida! Escolha de 1 a 4."
*/
#include <stdio.h>

int main() {
    int op;

    scanf("%d", &op);

    switch(op) {
        case 1:
            printf("Combo Hamburguer + Batata + Refri - R$ 30,00");
            break;
        case 2:
            printf("Combo Pizza Brotinho + Refri - R$ 25,00");
            break;
        case 3:
            printf("Combo Salada + Suco Natural - R$ 22,00");
            break;
        case 4:
            printf("Combo Balde de Frango + Molho - R$ 35,00");
            break;
        default:
            printf("Opcao invalida!");
    }

    return 0;
}
